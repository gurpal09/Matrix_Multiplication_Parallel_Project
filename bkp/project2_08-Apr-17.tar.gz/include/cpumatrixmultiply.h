#ifndef CPUMATRIXMULTIPLY_H
#define CPUMATRIXMULTIPLY_H

void CPU_Matrix_Multiply(int m, int n, int k, double *a, double *b, double *c);

#endif
