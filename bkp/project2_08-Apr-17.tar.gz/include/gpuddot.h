#ifndef GPUDDOT_H
#define GPUDDOT_H


void GPU_ddot(int m, int n, int k, double *a, double *bcol, double *c);

#endif
