#ifndef GPUDAXPY_H
#define GPUDAXPY_H



void GPU_daxpy(int m, int n, int k, double *acol, double *bcol, double *c);

#endif
