#ifndef CPUDDOT_H
#define CPUDDOT_H

void CPU_ddot(int m, int n, int k, double *a, double *bcol, double *c);

#endif
