#ifndef CPUDAXPY_H
#define CPUDAXPY_H


void CPU_daxpy(int m, int n, int k, double *acol, double *bcol, double *c);

#endif
