#ifndef GPUMATRIXMULTIPLY_H
#define GPUMATRIXMULTIPLY_H

__global__ void GPU_Matrix_Multiply_Kernel(double *A, double *B, double *C, int N); 

#endif
